##########################################################################################
#
# Magisk Module Template Config Script
# by topjohnwu
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
AUTOMOUNT=true

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "      OpenSSH for Android      "
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
REPLACE="
"

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  set_perm_recursive  $MODPATH  0  0  0755  0644

  cp -af $INSTALLER/common/$ARCH $MODPATH/usr
  mkdir $MODPATH/usr/bin/raw
  cp -af $INSTALLER/common/magisk_ssh_library_wrapper $MODPATH/usr/bin/raw
  for f in scp sftp sftp-server ssh ssh-keygen sshd; do
    mv $MODPATH/usr/bin/$f $MODPATH/usr/bin/raw/$f
    ln -s ./raw/magisk_ssh_library_wrapper $MODPATH/usr/bin/$f
  done
  cp -af $INSTALLER/common/opensshd.init $MODPATH/
  chmod -R 755 $MODPATH/usr/bin
  chmod 755 $MODPATH/opensshd.init
  ln -s ./libcrypto.so.1.0.0 $MODPATH/usr/lib/libcrypto.so
  mkdir -p /data/ssh
  mkdir -p /data/ssh/root/.ssh
  mkdir -p /data/ssh/shell/.ssh
  chown shell:shell /data/ssh/shell
  chown shell:shell /data/ssh/shell/.ssh
  chmod 700 /data/ssh/{shell,root}/.ssh
  [ -f /data/ssh/sshd_config ] || (cp -a $INSTALLER/common/sshd_config /data/ssh; chown root:root /data/ssh/sshd_config; chmod 600 /data/ssh/sshd_config)
}

##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.

